Janta Kalyan Yojna can provide a secure and transparent platform for donations

This is a web3 based platform designed to facilitate the collection of financial contributions from donors for healthcare-related causes under a potential govt  backed initiative

## Local Deployment
You can deploy the contract to any network with:

```cmd
cd backend
brownie run scripts/deploy.py
```

You can run the frontend on your local environment using the following commands
```cmd
cd frontend
npm install
npm run dev
```
